import * as React from 'react';
import { useTheme } from '@material-ui/core/styles';
import logo from './OSAT.png';
const Logo = (props) => {

    return (<img src={logo} alt="Logo" />)};
export default Logo;