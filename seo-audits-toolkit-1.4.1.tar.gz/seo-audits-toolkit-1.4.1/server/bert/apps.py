from django.apps import AppConfig


## Basic file created by django. Don't touch it.
## You need to add your app to core/settings -> INSTALLED_APPS = [
# 'bert.apps.BertConfig' for example
# ]
class BertConfig(AppConfig):
    name = 'bert'
